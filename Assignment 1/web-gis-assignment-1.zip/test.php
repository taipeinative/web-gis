<?php
  //echo "123";
  echo rand(10,20);    //rand(int $min, int $max): int  , both are included

?>